<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>{{$gnl->title}}</title>
</head>

<body>
    {!! $form !!}
<script>
    document.getElementById("coinPayForm").submit();
</script>
</body>

</html>
    
	