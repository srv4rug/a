
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- blog page content area start-->
    <div class="blog-page-conent">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6">
                    <div class="single-blog-post"><!-- single blog page -->
                        <div class="thumb">
                            <img src="<?php echo e(asset($data->image)); ?>" alt="blog images">
                        </div>
                        <div class="content">
                            <a href="<?php echo e(route('blog.details',$data->id)); ?>"><h4 class="title"><?php echo e($data->title); ?></h4></a>
                            <div class="post-meta">
                                <span class="time"><i class="far fa-clock"></i> <?php echo e(date(' l jS F Y', strtotime($data->created_at))); ?></span>
                            </div>
                            <p><?php echo e(str_limit($data->des, 100)); ?> </p>
                            <a href="<?php echo e(route('blog.details',$data->id)); ?>" class="readmore">Read More</a>
                        </div>
                    </div><!-- //. single blog page content -->
                </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php echo e($blog->links()); ?>

        </div>
    </div>
    <!-- blog page content area end-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>