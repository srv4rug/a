<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- about page content area start -->
    <section class="about-page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-page-content-inner"><!-- about page content inner -->
                        <div class="col-lg-12 col-md-12 col-sm-12 col-rm-12">
                            <div class="single-practise-box margin-bottom-40">
                                <div class="content text-center" style="padding: 21px 30px 17px 30px;">

                                    <form action="<?php echo e(route('user.card.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>

                                        <input type="hidden" name="qty" value="<?php echo e($qty); ?>">
                                        <input type="hidden" name="sub_cat" value="<?php echo e($sub->id); ?>">

                                        <?php $balance = Auth::user()->balance ?>
                                        <h4 class="title"><?php echo e($sub->sub_cat->cat_name); ?></h4>
                                        <hr>
                                        <h5 class="title"><?php echo e($sub->name); ?></h5>
                                        <hr>
                                        <strong class="title">Price: <?php echo e($sub->price); ?> <?php echo e($gnl->cur); ?> / card</strong>
                                        <hr>
                                        <strong class="title">Your Quantity: <?php echo e($qty); ?></strong>
                                        <hr>
                                        <strong class="title">Total Cost: <?php echo e($total = $qty*$sub->price); ?> <?php echo e($gnl->cur); ?></strong>
                                        <hr>
                                        <strong class="title">Current Balance: <?php echo e($balance); ?> <?php echo e($gnl->cur); ?></strong>
                                        <hr>
                                        <p></p>
                                        <?php if($balance >=  $total): ?>
                                            <input type="submit" class="submit-btn" value="Purchase">
                                        <?php else: ?>
                                            <a href="<?php echo e(url('home/deposit')); ?>" class="boxed-btn" >Deposit Now</a>
                                        <?php endif; ?>
                                    </form>

                                </div>
                            </div>
                            <!-- //. single practise box -->
                        </div>

                    </div><!-- //.about page content inner -->
                </div>
            </div>
        </div>
    </section>
    <!-- about page content area end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>