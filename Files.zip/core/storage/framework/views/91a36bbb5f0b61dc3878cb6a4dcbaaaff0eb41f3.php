<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- about page content area start -->
    <section class="about-page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="about-page-content-inner"><!-- about page content inner -->
                        <h2 class="title">My Cards</h2>

                        <div class="row">
                            <div class="col-lg-12 col-md-12">
                                <div class="tile">
                                    <div class="panel-group">
                                        <div class="panel panel-default">

                                            <div class="panel-body">
                                                <table class="table table-bordered table-hover">
                                                    <thead>
                                                    <tr class="text-center">
                                                        <th>Card Name</th>
                                                        <th>Bought Time</th>
                                                        <th>Action</th>
                                                    </tr>
                                                    </thead>
                                                    <tbody>
                                                    <?php if(count($usercard) > 0): ?>
                                                        <?php $__currentLoopData = $usercard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr class="text-center" id="tr_<?php echo e($tr->id); ?>">
                                                            
                                                                <td><?php echo e($tr->cats->cat_name); ?> -> <?php echo e($tr->card->name); ?></td>
                                                                <td><?php echo e(Carbon\Carbon::parse($tr->created_at)->format('d F Y - g:i A')); ?></td>
                                                                <td>
                                                                    <button class="btn btn-info btn-sm btn-block dtlsviebtn" data-toggle="modal"  data-target="#dtlsviebtnnn<?php echo e($tr->id); ?>" data-id="<?php echo e($tr->id); ?>" data-details="<?php echo e($tr->card->card_details); ?>" data-image="<?php echo e(asset($tr->card->card_image)); ?>">View</button>
                                                                </td>
                                                            </tr>
                                                            <div id="dtlsviebtnnn<?php echo e($tr->id); ?>" class="modal fade" role="dialog">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header headeingall">
                                                                            <h4 class="modal-title" style="text-align: center"><?php echo e($tr->card->name); ?></h4>
                                                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="modal-body">
                                                                                <div class="form-group">
                                                                                    <h4 class="fulldetls"><?php echo $tr->card_details; ?></h4>
                                                                                    <br>
                                                                                    <?php if(!empty($tr->card_image)): ?>
                                                                                        <img src="<?php echo e(asset('assets/images/cardimage/'.$tr->card_image)); ?>" style="width: 100%;height: 200px">
                                                                                    <?php else: ?>

                                                                                    <?php endif; ?>
                                                                                    <input type="hidden" name="delid" value="" class="delid">
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer" >
                                                                            <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                                                            <?php if($tr->status == 0): ?>
                                                                                <button type="button" class="btn btn-default pull-right" data-id="<?php echo e($tr->id); ?>">Used</button>
                                                                            <?php else: ?>
                                                                                <button type="button" class="btn btn-primary pull-right markused" data-id="<?php echo e($tr->id); ?>">Mark As Used</button>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php else: ?>
                                                        <tr>
                                                            <td colspan="4"><h3 style="text-align: center">Sorry ! Right now you don't have any card.</h3></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                    </tbody>
                                                </table>
                                                <?php echo e($usercard->links()); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div><!-- //.about page content inner -->
                </div>
            </div>
        </div>
    </section>
    <!-- about page content area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function () {

            $('.markused').click(function () {
                var id = $(this).data('id');

                $.ajax({
                    type : "POST",
                    url : "<?php echo e(route('chnageusercardshowstats')); ?>",
                    data : {
                        '_token' : "<?php echo e(csrf_token()); ?>",
                        'id' : id,
                    },
                    success:function (data) {
                        var btn = "<button class='btn btn-default pull-right'>" + 'used ' +  "</button>";
                        $('.markused').replaceWith(btn);
                        $('#dtlsviebtnnn'+data.id).modal('hide');
                        $('#tr_'+data.id).remove();
                        location.reload();
                    }
                });
            });

        })
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>