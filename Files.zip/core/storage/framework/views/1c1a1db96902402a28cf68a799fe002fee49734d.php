<nav class="navbar navbar-area navbar-expand-lg navbar-light ">
    <div class="container nav-container">
        <div class="logo-wrapper navbar-brand">
            <a href="<?php echo e(url('/')); ?>" class="logo main-logo">
                <img src="<?php echo e(asset('assets/images/')); ?>/logo/logo.png" style="width: 160px" alt="logo">
            </a>
        </div>
        <div class="collapse navbar-collapse" id="mirex">
            <!-- navbar collapse start -->
            <ul class="navbar-nav">
            <?php if(auth()->guard()->guest()): ?>
                <!-- navbar- nav -->
                <li class="nav-item active">
                    <a class="nav-link pl-0" href="<?php echo e(route('user.index')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('user.about')); ?>">About us</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('blog.in')); ?>">Blog</a>
                </li>
                <li class="nav-item ">
                    <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact us</a>
                </li>

                <li class="nav-item dropdown ">
                    <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">Account</a>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(route('login')); ?>">Login</a>
                        <a class="dropdown-item" href="<?php echo e(route('register')); ?>">Register</a>
                    </div>
                </li>
                <?php else: ?>

 
                     <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('home')); ?>">Dashboard</a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('user.buycard')); ?>">Buy Card</a>
                    </li>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown">My Card</a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="<?php echo e(route('user.mycard')); ?>">My Cards</a>
                            <a class="dropdown-item" href="<?php echo e(route('user.old.card')); ?>">Used Card</a>
                        </div>
                    </li>



                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('user.deposit')); ?>">Deposit</a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(route('user.transaction')); ?>">Transactions</a>
                    </li>

                    <li class="nav-item dropdown ">
                        <a class="nav-link dropdown-toggle" href="" data-toggle="dropdown"><?php echo e(Auth::user()->name); ?></a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#"> Balance : <?php echo e(Auth::user()->balance); ?> <?php echo e($gnl->cur); ?> </a>
                            <a class="dropdown-item" href="<?php echo e(route('user.change-password')); ?>">Change Password</a>
                            <a class="dropdown-item" href="<?php echo e(route('profile.index')); ?>">Profile</a>
                            <a class="dropdown-item" href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();">Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>


                <?php endif; ?>

            </ul>
            <!-- /.navbar-nav -->
        </div>


        <!-- /.navbar btn wrapper -->
        <div class="responsive-mobile-menu">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mirex" aria-controls="mirex"
                    aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
        <!-- navbar collapse end -->
    </div>
</nav>