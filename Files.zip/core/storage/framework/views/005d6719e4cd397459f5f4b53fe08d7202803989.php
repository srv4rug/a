

<?php $__env->startSection('content'); ?>
    <div class="tile">
        <div class="card">
            <div class="card-header bg-info">
                <div class="caption">
                    <h2 style="text-align: center; color: white">Transaction</h2>
                </div>
            </div>
            <div class="card-body">
                <div class="table-scrollable">
                    <div class="row">
                        <table class="table table-hover ">
                            <thead>
                            <tr>
                                <th>
                                    Date
                                </th>
                                <th>
                                    Transaction Number
                                </th>
                                <th>
                                    User
                                </th>

                                <th>
                                    Details
                                </th>
                                <th>
                                    Amount
                                </th>
                                <th>
                                    Balance
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $tran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e(date(' l jS F Y', strtotime($tr->created_at))); ?>

                                    </td>
                                    <td>
                                        <?php echo e($tr->trxid); ?>

                                    </td>
                                    <td>
                                        <a href="<?php echo e(url('admin/user/'.$tr->user_id)); ?>"><?php echo e($tr->user->name); ?></a>
                                    </td>

                                    <td>
                                        <?php echo e($tr->details); ?>

                                    </td>
                                    <td>
                                        <?php echo e($tr->amount); ?> <?php echo e($gnl->cursym); ?>

                                    </td>
                                    <td>
                                        <?php echo e($tr->balance); ?> <?php echo e($gnl->cursym); ?>

                                    </td>


                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tbody>
                        </table>
                        <?php echo e($tran->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>