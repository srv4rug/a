<?php $__env->startSection('content'); ?>
    <div class="tile">
        <div class="tile-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header bg-info">
                            <div class="caption">
                                <h2 style="text-align: center;color: white">Static Header</h2>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-scrollable table-responsive">
                                <form role="form" method="POST" action="<?php echo e(route('admin.static.head')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="form-group">
                                        <h4>Title</h4>

                                        <input type="text" value="<?php echo e($gnl->static_head); ?>" class="form-control"
                                               id="contact_number" name="static_head">
                                    </div>
                                    <div class="form-group">
                                        <h4>Detail</h4>

                                        <input type="text" value="<?php echo e($gnl->static_des); ?>" class="form-control"
                                               id="contact_number" name="static_des">
                                    </div>
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-success btn-block">Update</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="tile">
        <div class="card">
            <div class="card-header bg-info">
                <div class="caption">
                    <h2 style="text-align: center; color: white">Static Section</h2>
                </div>

            </div>
            <div class="card-body">
                <div class="row">
                    <?php $sl = 1; ?>
                    <?php $__currentLoopData = $stt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header text-center">
                                    Serial No: <strong><?php echo e($sl); ?></strong>

                                </div>
                                <div class="card-body">
                                    <form role="form" method="POST" action="<?php echo e(route('admin.staticupdate',$slide->id)); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('put'); ?>

                                        <div class="form-group">
                                            <h4>Title</h4>
                                            <input type="text" value="<?php echo e($slide->title); ?>" class="form-control"  name="title" >
                                        </div>
                                        <div class="form-group">
                                            <h4>Amount</h4>
                                            <input type="text" value="<?php echo e($slide->amount); ?>" class="form-control"  name="amount" >
                                        </div>
                                        <div class="form-group">
                                            <button type="submit" class="btn btn-success btn-block">Update</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php $sl = $sl+1; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>