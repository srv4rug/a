
<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="about-page-content-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <div class="about-page-content-inner table-responsive-md">
                        <table class="table">
                            <thead>
                            <tr>
                                <th style="text-align: center"> Date</th>
                                <th style="text-align: center">Transaction Number</th>
                                <th style="text-align: center">Details</th>
                                <th style="text-align: center">Amount</th>
                                <th style="text-align: center">Banlance</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(count($tran) > 0): ?>
                            <?php $__currentLoopData = $tran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr >
                                    <td style="text-align: center"><?php echo e(date(' l jS F Y', strtotime($tr->created_at))); ?></td>
                                    <td style="text-align: center"><?php echo e($tr->trxid); ?></td>
                                    <td style="text-align: center"><?php echo e($tr->details); ?></td>
                                    <td style="text-align: center"><?php echo e($tr->amount); ?> <?php echo e($gnl->cursym); ?></td>
                                    <td style="text-align: center"><?php echo e($tr->balance); ?> <?php echo e($gnl->cursym); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4"><h3 style="text-align: center">Sorry ! Right now you don't have any Transaction.</h3></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php echo e($tran->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('fontend.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>