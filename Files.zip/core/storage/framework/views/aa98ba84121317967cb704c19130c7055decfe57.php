<?php if(session('success')): ?>
<script type="text/javascript">
    $(document).ready(function(){
        $.notify({
            type: 'success',
            title: "Success!",
            message: "<?php echo e(session('success')); ?>"
        });
    });
</script>
<?php endif; ?>

<?php if(session('alert')): ?>
    <script type="text/javascript">
        $(document).ready(function(){
            $.notify({
                allow_dismiss: true,
                title: "Sorry!",
                message: "<?php echo e(session('alert')); ?>"
            },{
                type: 'danger'
            });
        });
    </script>
<?php endif; ?>



